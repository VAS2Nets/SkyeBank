<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once 'lib.php';

#$result = change_password('admin');
#var_dump(get_user('admin'));
#$result = update_smpp('197.253.10.25','2775', 'kannel2', '12345');
#echo $result;
#var_dump(get_smpp());
#var_dump(get_plugins());

#var_dump(get_plugin('6'));
#echo(is_user('admin'));
#if(is_user('admin2')) echo 'Validated';
echo test_smpp('192.168.1.154','2755','kannel2','12345');

?>

