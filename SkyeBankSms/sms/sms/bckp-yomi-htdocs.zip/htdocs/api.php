<?php

require_once 'rb.php';
R::setup('sqlite:data.db','admin','password');

