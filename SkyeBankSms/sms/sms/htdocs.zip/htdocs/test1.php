<?php
echo 'Working now! ..Ok (Stanley)';
?>