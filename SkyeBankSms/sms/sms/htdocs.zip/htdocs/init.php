<?php

require_once 'rb.php';
R::setup('sqlite:sqlite.db','admin','password');

?>